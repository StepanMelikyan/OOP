import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;

class Note {
    private String id;
    private String title;
    private String text;
    private Date createdAt;

    public Note() {
        id = UUID.randomUUID().toString();
        createdAt = new Date();
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getCreatedAt() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return sdf.format(createdAt);
    }
}

public class NotesApp {
    private static final String NOTES_DIRECTORY = "notes";

    public static void main(String[] args) {
        File notesDir = new File(NOTES_DIRECTORY);

        if (!notesDir.exists()) {
            notesDir.mkdirs();
        }

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nВыберите действие:");
            System.out.println("1. Создать новую записку");
            System.out.println("2. Просмотреть все записки");
            System.out.println("3. Просмотреть записку по ID");
            System.out.println("4. Удалить записку по ID");
            System.out.println("5. Выход");
            System.out.print("Введите номер действия: ");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    createNote();
                    break;
                case "2":
                    viewAllNotes();
                    break;
                case "3":
                    viewNoteById();
                    break;
                case "4":
                    deleteNoteById();
                    break;
                case "5":
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Неверный выбор. Попробуйте снова.");
                    break;
            }
        }
    }

    private static void createNote() {
        Note note = new Note();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Введите заголовок записки: ");
        String title = scanner.nextLine();
        note.setTitle(title);

        System.out.print("Введите текст записки: ");
        String text = scanner.nextLine();
        note.setText(text);

        try {
            File file = new File(NOTES_DIRECTORY, note.getId() + ".txt");
            FileWriter writer = new FileWriter(file);
            writer.write("ID: " + note.getId() + "\n");
            writer.write("Заголовок: " + note.getTitle() + "\n");
            writer.write("Дата создания: " + note.getCreatedAt() + "\n");
            writer.write("Текст:\n" + note.getText() + "\n");
            writer.close();

            System.out.println("Записка с ID " + note.getId() + " создана.");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Ошибка при создании записки.");
        }
    }

    private static void viewAllNotes() {
        File[] noteFiles = new File(NOTES_DIRECTORY).listFiles();
        if (noteFiles != null) {
            for (File file : noteFiles) {
                if (file.isFile()) {
                    try {
                        BufferedReader reader = new BufferedReader(new FileReader(file));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            System.out.println(line);
                        }
                        reader.close();
                        System.out.println();
                    } catch (IOException e) {
                        e.printStackTrace();
                        System.out.println("Ошибка при чтении записки.");
                    }
                }
            }
        } else {
            System.out.println("Нет доступных записок.");
        }
    }

    private static void viewNoteById() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите ID записки: ");
        String noteId = scanner.nextLine();
        File noteFile = new File(NOTES_DIRECTORY, noteId + ".txt");

        if (noteFile.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(noteFile));
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("Ошибка при чтении записки.");
            }
        } else {
            System.out.println("Записка с ID " + noteId + " не найдена.");
        }
    }

    private static void deleteNoteById() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите ID записки для удаления: ");
        String noteId = scanner.nextLine();
        File noteFile = new File(NOTES_DIRECTORY, noteId + ".txt");

        if (noteFile.exists()) {
            if (noteFile.delete()) {
                System.out.println("Записка с ID " + noteId + " удалена.");
            } else {
                System.out.println("Ошибка при удалении записки.");
            }
        } else {
            System.out.println("Записка с ID " + noteId + " не найдена.");
        }
    }
}
